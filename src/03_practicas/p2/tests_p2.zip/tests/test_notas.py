"""Pruebas para el problema de las calificaciones cualitativas."""

import unittest
import subprocess
import sys

TARGET = "notas"


def run(nota: float) -> str:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{nota}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return lines[-1]


class NotasTest(unittest.TestCase):
    def test_0_es_suspenso(self):
        self.assertEqual(
            run(0),
            "Calificación: Suspenso.",
            f"En {TARGET}.py, la calificación 0 debe ser «Suspenso».",
        )

    def test_12_es_incorrecta(self):
        self.assertEqual(
            run(12),
            "Nota numérica no válida.",
            f"En {TARGET}.py, la calificación 12 es incorrecta.",
        )
