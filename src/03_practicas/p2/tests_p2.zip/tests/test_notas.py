"""Pruebas para el problema de las calificaciones cualitativas."""

import unittest
import subprocess
import sys
import os

TARGET = "notas"


def run(nota: float) -> str:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{nota}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return lines[-1]


class NotasTest(unittest.TestCase):
    def test_0_es_suspenso(self):
        self.assertRegex(
            run(0),
            "Calificaci.n: Suspenso.",
            f"En {TARGET}.py, la calificación 0 debe ser «Suspenso».",
        )

    def test_12_es_incorrecta(self):
        self.assertRegex(
            run(12),
            "Nota num.rica no v.lida.",
            f"En {TARGET}.py, la calificación 12 es incorrecta.",
        )
