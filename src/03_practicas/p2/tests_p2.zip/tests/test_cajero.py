"""Pruebas para el problema de las calificaciones cualitativas."""

import unittest
import subprocess
import sys

TARGET = "cajero"


def run(euros: int) -> list[str]:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{euros}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    return proc.stdout.strip().splitlines()


class CajeroTest(unittest.TestCase):
    def test_0_euros_es_incorrecto(self):
        self.assertEqual(
            run(0)[-1],
            "Error: la cantidad a retirar tiene que ser positiva.",
            f"En {TARGET}.py, con 0 €, no se deben emitir billetes.",
        )

    def test_10_euros_es_un_billete_de_10(self):
        self.assertEqual(
            run(10)[-3:],
            ["Billetes 50 €: 0", "Billetes 20 €: 0", "Billetes 10 €: 1"],
            f"En {TARGET}.py, con 10 euros, se debe emitir un billete de 10.",
        )

    def test_1000_euros_es_incorrecto(self):
        self.assertEqual(
            run(1000)[-1],
            "Error: la cantidad a retirar excede el límite máximo.",
            f"En {TARGET}.py, con más 600 euros, no se deben emitir billetes.",
        )

    def test_15_euros_es_incorrecto(self):
        self.assertEqual(
            run(15)[-1],
            "Error: la cantidad a retirar tiene que ser un múltiplo de 10.",
            f"En {TARGET}.py, con 15 euros, no se pueden emitir billetes.",
        )
