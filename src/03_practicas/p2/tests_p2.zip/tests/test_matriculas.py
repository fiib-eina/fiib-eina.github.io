"""Pruebas para el problema de las matrículas de honor."""

import unittest
import subprocess
import sys
import os

TARGET = "matriculas"


def run(matriculados: int) -> str:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{matriculados}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return lines[-1]


class MatriculasTest(unittest.TestCase):
    def test_0_matriculados(self):
        self.assertRegex(
            run(0),
            "El n.mero de matriculados tiene que ser positivo.",
            f"En {TARGET}.py, no se deben permitir valores no positivos.",
        )

    def test_79_matriculados_tienen_3_matriculas(self):
        self.assertRegex(
            run(79),
            "Se pueden otorgar como m.ximo 3 matr.culas de honor.",
            f"En {TARGET}.py, con 79 matriculados se pueden dar 3 matrículas de honor.",
        )
