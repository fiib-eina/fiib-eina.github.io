"""Pruebas para el problema de las matrículas de honor."""

import unittest
import subprocess
import sys

TARGET = "matriculas"


def run(matriculados: int) -> str:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{matriculados}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return lines[-1]


class MatriculasTest(unittest.TestCase):
    def test_0_matriculados(self):
        self.assertEqual(
            run(0),
            "El número de matriculados tiene que ser positivo.",
            f"En {TARGET}.py, no se deben permitir valores no positivos.",
        )

    def test_79_matriculados_tienen_3_matriculas(self):
        self.assertEqual(
            run(79),
            "Se pueden otorgar como máximo 3 matrículas de honor.",
            f"En {TARGET}.py, con 79 matriculados se pueden dar 3 matrículas de honor.",
        )
