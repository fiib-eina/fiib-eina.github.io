"""Pruebas para el problema de las calificaciones cualitativas."""

import unittest
import subprocess
import sys

TARGET = "malabares"


def run(numero: int) -> int:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{numero}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return int(lines[-1].split(":")[-1])


class MalabaresTest(unittest.TestCase):
    def test_0_es_0(self):
        self.assertEqual(
            run(0),
            0,
            f"En {TARGET}.py, cuando el número es 0, el resultado debe ser 0.",
        )

    def test_5_es_25(self):
        self.assertEqual(
            run(5),
            25,
            f"En {TARGET}.py, cuando el número es 5, el resultado debe ser 25.",
        )

    def test_menos_2_es_1(self):
        self.assertEqual(
            run(-2),
            1,
            f"En {TARGET}.py, cuando el número es -2, el resultado debe ser 1.",
        )

    def test_menos_45_es_45(self):
        self.assertEqual(
            run(-45),
            45,
            f"En {TARGET}.py, cuando el número es -45, el resultado debe ser 45.",
        )

    def test_menos_68_es_menos_17(self):
        self.assertEqual(
            run(-68),
            -17,
            f"En {TARGET}.py, cuando el número es -68, el resultado debe ser -17.",
        )
