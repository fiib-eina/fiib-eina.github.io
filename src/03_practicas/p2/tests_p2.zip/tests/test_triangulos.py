"""Pruebas para el problema de las calificaciones cualitativas."""

import unittest
import subprocess
import sys

TARGET = "triangulos"


def run(a: str, b: str, c: str) -> str:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{a}\n{b}\n{c}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return lines[-1]


class TriangulosTest(unittest.TestCase):
    def test_0_0_0_es_invalido(self):
        self.assertEqual(
            run("0", "0", "0"),
            "Algún dato no es estrictamente positivo.",
            f"En {TARGET}.py, cuando los tres lados son 0, no es un triángulo.",
        )

    def test_5_5_5_es_equilatero(self):
        self.assertEqual(
            run("5", "+5", "05"),
            "El triángulo es equilátero.",
            f"En {TARGET}.py, cuando los tres lados son 5, es un triángulo equilátero.",
        )

    def test_2_2_1_es_isosceles(self):
        self.assertEqual(
            run("2", "+2", "1"),
            "El triángulo es isósceles.",
            f"En {TARGET}.py, cuando los lados son 2, 2 y 1, es un triángulo isósceles.",
        )

    def test_3_4_5_es_escaleno(self):
        self.assertEqual(
            run("3", "4", "5"),
            "El triángulo es escaleno.",
            f"En {TARGET}.py, cuando los lados son 3, 4 y 5, es un triángulo escaleno.",
        )

    def test_3_negativo_3_es_invalido(self):
        self.assertEqual(
            run("3", "-8", "3"),
            "Algún dato no es estrictamente positivo.",
            f"En {TARGET}.py, cuando algún lado es negativo, no es un triángulo.",
        )
