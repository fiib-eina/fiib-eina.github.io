"""Pruebas para el problema de las calificaciones cualitativas."""

import unittest
import subprocess
import sys
import os

TARGET = "triangulos"


def run(a: str, b: str, c: str) -> str:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{a}\n{b}\n{c}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return lines[-1]


class TriangulosTest(unittest.TestCase):
    def test_0_0_0_es_invalido(self):
        self.assertRegex(
            run("0", "0", "0"),
            "Alg.n dato no es estr.ctamente positivo.",
            f"En {TARGET}.py, cuando los tres lados son 0, no es un tri.ngulo.",
        )

    def test_5_5_5_es_equilatero(self):
        self.assertRegex(
            run("5", "+5", "05"),
            "El tri.ngulo es equil.tero.",
            f"En {TARGET}.py, cuando los tres lados son 5, es un tri.ngulo equil.tero.",
        )

    def test_2_2_1_es_isosceles(self):
        self.assertRegex(
            run("2", "+2", "1"),
            "El tri.ngulo es is.sceles.",
            f"En {TARGET}.py, cuando los lados son 2, 2 y 1, es un tri.ngulo is.sceles.",
        )

    def test_3_4_5_es_escaleno(self):
        self.assertRegex(
            run("3", "4", "5"),
            "El tri.ngulo es escaleno.",
            f"En {TARGET}.py, cuando los lados son 3, 4 y 5, es un tri.ngulo escaleno.",
        )

    def test_3_negativo_3_es_invalido(self):
        self.assertRegex(
            run("3", "-8", "3"),
            "Alg.n dato no es estr.ctamente positivo.",
            f"En {TARGET}.py, cuando algun lado es negativo, no es un tri.ngulo.",
        )
