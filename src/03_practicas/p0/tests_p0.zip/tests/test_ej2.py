import unittest
import subprocess
import sys
import re

TARGET = "ej2"


def run(num1):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{num1}\n",
        text=True,
        capture_output=True,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return float(lines[-1])


class Ej1(unittest.TestCase):
    def test_1(self):
        self.assertAlmostEqual(
            run(1),
            3.1416,
            places=4,
            msg=f"En {TARGET}.py, el resultado para 1 debería ser 3.1416",
        )

    def test_2(self):
        self.assertAlmostEqual(
            run(-1),
            3.1416,
            places=4,
            msg=f"En {TARGET}.py, el resultado para -1 debería ser 3.1416",
        )

    def test_3(self):
        self.assertAlmostEqual(
            run(-3),
            28.2743,
            places=4,
            msg=f"En {TARGET}.py, el resultado para -3 debería ser 28.2743",
        )
