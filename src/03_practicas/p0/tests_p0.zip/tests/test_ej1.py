import unittest
import subprocess
import sys
import re

TARGET = "ej1"


def run(num1, num2):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{num1}\n{num2}\n",
        text=True,
        capture_output=True,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return int(lines[-1])


class Ej1(unittest.TestCase):
    def test_1(self):
        self.assertEqual(
            run(1, 2),
            3,
            msg=f"En {TARGET}.py, la suma de 1 y 2 debería ser 3.",
        )

    def test_2(self):
        self.assertEqual(
            run(-1, 2),
            1,
            msg=f"En {TARGET}.py, la suma de -1 y 2 debería ser 1.",
        )

    def test_3(self):
        self.assertEqual(
            run(-1, -1),
            -2,
            msg=f"En {TARGET}.py, la suma de -1 y -1 debería ser -2",
        )
