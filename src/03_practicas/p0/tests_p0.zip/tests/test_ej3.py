import unittest
import subprocess
import sys
import re

TARGET = "ej3"


def run(num1):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{num1}\n",
        text=True,
        capture_output=True,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return float(lines[-1])


class Ej1(unittest.TestCase):
    def test_1(self):
        self.assertAlmostEqual(
            run(5),
            5.0,
            places=4,
            msg=f"En {TARGET}.py, el resultado para 5 debería ser 5.0",
        )

    def test_2(self):
        self.assertAlmostEqual(
            run(-5),
            5.0,
            places=4,
            msg=f"En {TARGET}.py, el resultado para -5 debería ser 5.0",
        )
