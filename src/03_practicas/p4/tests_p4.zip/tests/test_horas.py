# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de las horas en lenguaje natural."""

from io import StringIO
import unittest
import sys

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("1\n")
sys.stdout = StringIO()
import horas

sys.stdin = stdin_backup
sys.stdout = stdout_backup

TARGET = "horas"


class HorasTest(unittest.TestCase):
    """Clase de pruebas para el problema de las horas en lenguaje natural."""

    def tests_hora_en_palabras(self):
        """Pruebas para la función hora_en_palabras."""
        casos = [
            # (hora, esperado)
            (1, "La una"),
            (2, "Las dos"),
            (3, "Las tres"),
            (4, "Las cuatro"),
            (5, "Las cinco"),
            (6, "Las seis"),
            (7, "Las siete"),
            (8, "Las ocho"),
            (9, "Las nueve"),
            (10, "Las diez"),
            (11, "Las once"),
            (12, "Las doce"),
            (13, "La una"),
            (14, "Las dos"),
            (15, "Las tres"),
            (16, "Las cuatro"),
            (17, "Las cinco"),
            (18, "Las seis"),
            (19, "Las siete"),
            (20, "Las ocho"),
            (21, "Las nueve"),
            (22, "Las diez"),
            (23, "Las once"),
            (24, "Las doce"),
        ]

        for hora, esperado in casos:
            actual = horas.hora_en_palabras(hora)
            with self.subTest(f"hora_en_palabras({hora})"):
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f'hora_en_palabras({hora}) debe ser "{esperado}", pero se obtuvo "{actual}".',
                )

    def tests_minutos_en_palabras(self):
        """Pruebas para la función minutos_en_palabras."""
        casos = [
            # (minutos, esperado)
            (0, ""),
            (15, "y cuarto"),
            (30, "y media"),
            (45, "menos cuarto"),
        ]

        for minutos, esperado in casos:
            actual = horas.minutos_en_palabras(minutos)
            with self.subTest(f"minutos_en_palabras({minutos})"):
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f'minutos_en_palabras({minutos}) debe ser "{esperado}", pero se obtuvo "{actual}".',
                )

    def tests_periodo_del_dia(self):
        """Pruebas para la función periodo_del_dia."""
        casos = [
            # (hora, esperado)
            (0, "de la madrugada"),
            (1, "de la madrugada"),
            (5, "de la madrugada"),
            (6, "de la mañana"),
            (11, "de la mañana"),
            (12, "del mediodía"),
            (14, "del mediodía"),
            (15, "de la tarde"),
            (16, "de la tarde"),
            (19, "de la noche"),
        ]

        for hora, esperado in casos:
            actual = horas.periodo_del_dia(hora)
            with self.subTest(f"periodo_del_dia({hora})"):
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f'periodo_del_dia({hora}) debe ser "{esperado}", pero se obtuvo "{actual}".',
                )

    def tests_leer_hora(self):
        """Pruebas para la función leer_hora."""
        casos = [
            # (hora, minutos, esperado)
            (1, 0, "La una de la madrugada"),
            (3, 0, "Las tres de la madrugada"),
            (3, 15, "Las tres y cuarto de la madrugada"),
            (3, 30, "Las tres y media de la madrugada"),
            (3, 45, "Las cuatro menos cuarto de la madrugada"),
            (5, 45, "Las seis menos cuarto de la madrugada"),
            (6, 0, "Las seis de la mañana"),
            (12, 0, "Las doce del mediodía"),
            (13, 0, "La una del mediodía"),
            (15, 0, "Las tres de la tarde"),
            (19, 0, "Las siete de la noche"),
            (24, 0, "Las doce de la noche"),
        ]

        for hora, minutos, esperado in casos:
            actual = horas.leer_hora(hora, minutos)
            with self.subTest(f"leer_hora({hora}, {minutos})"):
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f'leer_hora({hora}, {minutos}) debe ser "{esperado}", pero se obtuvo "{actual}".',
                )
