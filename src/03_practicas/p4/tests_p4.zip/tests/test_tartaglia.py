# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema del triángulo de Tartaglia."""

from io import StringIO
import unittest
import sys

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("1\n")
sys.stdout = StringIO()
import tartaglia

sys.stdin = stdin_backup
sys.stdout = stdout_backup

TARGET = "tartaglia"


class TartagliaTest(unittest.TestCase):
    """Clase de pruebas para el problema del triángulo de Tartaglia."""

    def tests_coeficiente_binomial(self):
        """Pruebas para la función coeficiente_binomial."""
        casos = [
            # (n, k, esperado)
            (0, 0, 1),
            (1, 0, 1),
            (1, 1, 1),
            (2, 0, 1),
            (2, 1, 2),
            (2, 2, 1),
            (3, 0, 1),
            (3, 1, 3),
            (3, 2, 3),
            (3, 3, 1),
            (4, 0, 1),
            (5, 2, 10),
            (10, 3, 120),
        ]

        for n, k, esperado in casos:
            actual = tartaglia.coeficiente_binomial(n, k)
            with self.subTest(f"coeficiente_binomial({n}, {k})"):
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f"coeficiente_binomial({n}, {k}) debe ser {esperado}, pero se obtuvo {actual}.",
                )
