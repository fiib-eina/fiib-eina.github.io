# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los códigos perdidos."""

from io import StringIO
import unittest
import sys

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("1\n")
sys.stdout = StringIO()
import codigos_perdidos

sys.stdin = stdin_backup
sys.stdout = stdout_backup

TARGET = "codigos_perdidos"


class CodigosPerdidosTest(unittest.TestCase):
    """Clase de pruebas para el problema de los códigos perdidos."""

    def tests_sumar_cifras(self):
        """Pruebas para la función sumar_cifras."""
        casos = [
            # (n, suma_esperada)
            (123, 6),
            (1234, 10),
            (1, 1),
            (0, 0),
            (100, 1),
        ]

        for n, suma_esperada in casos:
            suma_actual = codigos_perdidos.sumar_cifras(n)
            with self.subTest(f"sumar_cifras({n})"):
                self.assertEqual(
                    suma_actual,
                    suma_esperada,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f"sumar_cifras({n}) debe ser {suma_esperada}, pero se obtuvo {suma_actual}.",
                )

    def tests_codigos_perdidos(self):
        """Pruebas para la función codigos_perdidos."""
        casos = [
            # (n, m, esperado)
            (-1, 20, -1),
            (20, 10, -1),
            (10, 20, 1),
            (10, 99, 240),
        ]

        for n, m, esperado in casos:
            sys.stdout = StringIO()
            actual = codigos_perdidos.codigos_perdidos(n, m)
            sys.stdout = stdout_backup
            with self.subTest(f"codigos_perdidos({n}, {m})"):
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f"codigos_perdidos({n}, {m}) debe ser {esperado}, pero se obtuvo {actual}.",
                )
