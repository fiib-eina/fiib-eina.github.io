# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
from types import SimpleNamespace

TARGET = "amigos"

try:
    stdin_backup = sys.stdin
    stdout_backup = sys.stdout
    sys.stdin = StringIO("1\n")
    sys.stdout = StringIO()

    import amigos
    sys.stdin = stdin_backup
    sys.stdout = stdout_backup
except Exception as e:
    print(f"\n***** ERROR al importar {TARGET}.py: {e}")
    def _err(*args, **kwargs):
        raise ImportError(f"ERROR: El modulo no pudo ser importado: {e}")
    amigos = SimpleNamespace(
        suma_divisores_propios=_err,
        son_amigos=_err,
    )


class AmigosTest(unittest.TestCase):
    """Clase de pruebas para el problema de los números amigos."""

    def tests_suma_divisores_propios(self):
        """Pruebas para la función suma_divisores_propios."""
        casos = [
            # (n, suma_esperada)
            (24, 36),
            (220, 284),
            (284, 220),
            (1184, 1210),
        ]

        for n, suma_esperada in casos:
            suma_actual = amigos.suma_divisores_propios(n)
            with self.subTest(f"suma_divisores_propios({n})"):
                self.assertEqual(
                    suma_actual,
                    suma_esperada,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f"suma_divisores_propios({n}) debe ser {suma_esperada}, "
                    + f"pero se obtuvo {suma_actual}.",
                )

    def tests_son_amigos(self):
        """Pruebas para la función son_amigos."""
        casos = [
            # (n, m, esperado)
            (12, 16, False),
            (40, 50, False),
            (220, 284, True),
            (284, 220, True),
            (220, 285, False),
            (220, 220, False),
            (1184, 1210, True),
            (1210, 1184, True),
        ]

        for n, m, esperado in casos:
            actual = amigos.son_amigos(n, m)
            with self.subTest(f"son_amigos({n}, {m})"):
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"\n***** ERROR en {TARGET}.py: "
                    + f"son_amigos({n}, {m}) debe ser {esperado}, pero se obtuvo {actual}.",
                )
