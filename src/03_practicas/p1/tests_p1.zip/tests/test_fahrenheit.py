"""Pruebas para el ejercicio de conversión de Fahrenheit a Celsius."""

import unittest
import subprocess
import sys

TARGET = "fahrenheit"


def run(num1):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{num1}\n",
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return float(lines[-1])


class FahrenheitTest(unittest.TestCase):
    def test_0F_son_menos_17_78C(self):
        self.assertAlmostEqual(
            run(0),
            -17.77777777777778,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 0 °F debería ser de -17.7778 °C.",
        )

    def test_32F_son_0C(self):
        self.assertAlmostEqual(
            run(32),
            0,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 32 °F debería ser de 0 °C.",
        )

    def test_212F_son_100C(self):
        self.assertAlmostEqual(
            run(212),
            100,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 212 °F debería ser de 100 °C.",
        )

    def test_menos_459_67F_son_menos_273_15C(self):
        self.assertAlmostEqual(
            run(-459.67),
            -273.15,
            places=4,
            msg=f"En {TARGET}.py, la conversión de -459.67 °F debería ser de -273.15 °C.",
        )

    def test_100F_son_37_78C(self):
        self.assertAlmostEqual(
            run(100),
            37.77777777777778,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 100 °F debería ser de 37.7778 °C.",
        )
