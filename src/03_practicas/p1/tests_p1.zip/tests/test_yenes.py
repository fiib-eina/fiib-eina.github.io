"""Pruebas para el ejercicio de conversión de euros a yenes."""

import unittest
import subprocess
import sys

TARGET = "yenes"


def run(num1):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{num1}\n",
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return int(lines[-1])


class YenesTest(unittest.TestCase):
    def test_0_euros_son_0_yenes(self):
        self.assertEqual(
            run(0),
            0,
            msg=f"En {TARGET}.py, la conversión de 0 € debería ser de 0 ¥.",
        )

    def test_0_01_euros_son_2_yenes(self):
        self.assertEqual(
            run(0.01),
            2,
            msg=f"En {TARGET}.py, la conversión de 0.01 € debería ser de 2 ¥.",
        )

    def test_43_65_euros_son_7029_yenes(self):
        self.assertEqual(
            run(43.65),
            7029,
            msg=f"En {TARGET}.py, la conversión de 43.65 € debería ser de 7029 ¥.",
        )

    def test_43_69_euros_son_7036_yenes(self):
        self.assertEqual(
            run(43.69),
            7036,
            msg=f"En {TARGET}.py, la conversión de 43.69 € debería ser de 7036 ¥.",
        )
