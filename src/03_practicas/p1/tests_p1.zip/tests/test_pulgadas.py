"""Pruebas para el ejercicio de conversión de centímetros a pulgadas."""

import unittest
import subprocess
import sys

TARGET = "pulgadas"


def run(num1):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{num1}\n",
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return float(lines[-1])


class PulgadasTest(unittest.TestCase):
    def test_1_cm_son_0_3937_pulgadas(self):
        self.assertAlmostEqual(
            run(1),
            0.39370078740157477,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 1 cm debería ser de 0.39370078740157477 pulgadas.",
        )

    def test_25_4_cm_son_10_pulgadas(self):
        self.assertAlmostEqual(
            run(25.4),
            10,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 25.4 cm debería ser de 10 pulgadas.",
        )

    def test_84_025_cm_son_33_0807_pulgadas(self):
        self.assertAlmostEqual(
            run(84.025),
            33.08070866141732,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 84.025 cm debería ser de 33.08070866141732 pulgadas.",
        )

    def test_0_cm_son_0_pulgadas(self):
        self.assertAlmostEqual(
            run(0),
            0,
            places=4,
            msg=f"En {TARGET}.py, la conversión de 0 cm debería ser de 0 pulgadas.",
        )
