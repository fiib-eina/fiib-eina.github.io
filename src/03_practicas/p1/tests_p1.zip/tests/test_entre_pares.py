"""Pruebas para el ejercicio de condiciones booleanas"""

import unittest
import subprocess
import sys

TARGET = "entre_pares"


def run(num1: int, num2: int, num3: int) -> bool:
    """Ejecuta el programa con los tres números dados y devuelve el resultado booleano."""
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{num1}\n{num2}\n{num3}\n",
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return lines[-1] == "True"


class EntreParesTest(unittest.TestCase):
    """Pruebas para el ejercicio de condiciones booleanas."""

    def test_0(self):
        """Prueba con todos los números iguales a 0."""
        self.assertFalse(
            run(0, 0, 0),
            msg=f"En {TARGET}.py, los enteros 0, 0 y 0 **no** cumplen todas las condiciones.",
        )

    def test_cumplen_todas_las_condiciones(self):
        """Prueba con números que cumplen todas las condiciones."""
        self.assertTrue(
            run(2, 4, 8),
            msg=f"En {TARGET}.py, los enteros 2, 4 y 8 cumplen todas las condiciones.",
        )

    def test_primero_impar(self):
        """Prueba con el primer número impar."""
        self.assertFalse(
            run(3, 4, 8),
            msg=f"En {TARGET}.py, los enteros 3, 4 y 8 **no** cumplen todas las condiciones.",
        )

    def test_segundo_impar(self):
        """Prueba con el segundo número impar."""
        self.assertFalse(
            run(2, 5, 8),
            msg=f"En {TARGET}.py, los enteros 2, 5 y 8 **no** cumplen todas las condiciones.",
        )

    def test_tercero_impar(self):
        """Prueba con el tercer número impar."""
        self.assertFalse(
            run(2, 4, 9),
            msg=f"En {TARGET}.py, los enteros 2, 4 y 9 **no** cumplen todas las condiciones.",
        )

    def test_primero_negativo(self):
        """Prueba con el primer número negativo."""
        self.assertFalse(
            run(-2, 4, 8),
            msg=f"En {TARGET}.py, los enteros -2, 4 y 8 **no** cumplen todas las condiciones.",
        )

    def test_segundo_negativo(self):
        """Prueba con el segundo número negativo."""
        self.assertFalse(
            run(2, -4, 8),
            msg=f"En {TARGET}.py, los enteros 2, -4 y 8 **no** cumplen todas las condiciones.",
        )

    def test_tercero_negativo(self):
        """Prueba con el tercer número negativo."""
        self.assertFalse(
            run(2, 4, -8),
            msg=f"En {TARGET}.py, los enteros 2, 4 y -8 **no** cumplen todas las condiciones.",
        )

    def test_segundo_menor_que_primero(self):
        """Prueba con el segundo número menor que el primero."""
        self.assertFalse(
            run(4, 2, 8),
            msg=f"En {TARGET}.py, los enteros 4, 2 y 8 **no** cumplen todas las condiciones.",
        )

    def test_segundo_mayor_que_tercero(self):
        """Prueba con el segundo número mayor que el tercero."""
        self.assertFalse(
            run(8, 10, 4),
            msg=f"En {TARGET}.py, los enteros 8, 10 y 4 **no** cumplen todas las condiciones.",
        )

    def test_segundo_igual_que_primero(self):
        """Prueba con el segundo número igual que el primero."""
        self.assertFalse(
            run(4, 4, 8),
            msg=f"En {TARGET}.py, los enteros 4, 4 y 8 **no** cumplen todas las condiciones.",
        )

    def test_segundo_igual_que_tercero(self):
        """Prueba con el segundo número igual que el tercero."""
        self.assertFalse(
            run(8, 10, 10),
            msg=f"En {TARGET}.py, los enteros 8, 10 y 10 **no** cumplen todas las condiciones.",
        )
