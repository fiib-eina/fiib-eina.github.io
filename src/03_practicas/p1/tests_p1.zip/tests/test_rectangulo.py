"""Pruebas para el ejercicio de cálculo del área y perímetro de un rectángulo."""

import unittest
import subprocess
import sys

TARGET = "rectangulo"


def run(x1, y1, x2, y2):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{x1}\n{y1}\n{x2}\n{y2}\n",
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return float(lines[-4]), float(lines[-1])


class RectanguloTest(unittest.TestCase):
    def test_0(self):
        (area, perimetro) = run(0, 0, 0, 0)
        with self.subTest("Área del rectángulo con vértices (0, 0) y (0, 0)."):
            self.assertAlmostEqual(
                area,
                0,
                places=4,
                msg=f"En {TARGET}.py, el área del rectángulo con vértices (0, 0) y (0, 0) debería ser 0.",
            )
        with self.subTest(
            "Perímetro del rectángulo con vértices (0, 0) y (0, 0) debería ser 0."
        ):
            self.assertAlmostEqual(
                perimetro,
                0,
                places=4,
                msg=f"En {TARGET}.py, el perímetro del rectángulo con vértices (0, 0) y (0, 0) debería ser 0.",
            )

    def test_coordenadas_enteras(self):
        (area, perimetro) = run(2, 3, 5, 6)
        with self.subTest("Área del rectángulo con vértices (2, 3) y (5, 6)."):
            self.assertAlmostEqual(
                area,
                9,
                places=4,
                msg=f"En {TARGET}.py, el área del rectángulo con vértices (2, 3) y (5, 6) debería ser 9.",
            )
        with self.subTest(
            "Perímetro del rectángulo con vértices (2, 3) y (5, 6)."
        ):
            self.assertAlmostEqual(
                perimetro,
                12,
                places=4,
                msg=f"En {TARGET}.py, el perímetro del rectángulo con vértices (2, 3) y (5, 6) debería ser 12.",
            )

    def test_coordenadas_reales(self):
        (area, perimetro) = run(1.5, 7.4, 6.8, 2.3)
        with self.subTest(
            "Área del rectángulo con vértices (1.5, 7.4) y (6.8, 2.3)."
        ):
            self.assertAlmostEqual(
                area,
                27.03,
                places=4,
                msg=f"En {TARGET}.py, el área del rectángulo con vértices (1.5, 7.4) y (6.8, 2.3) debería ser 27.03.",
            )
        with self.subTest(
            "Perímetro del rectángulo con vértices (1.5, 7.4) y (6.8, 2.3)."
        ):
            self.assertAlmostEqual(
                perimetro,
                20.8,
                places=4,
                msg=f"En {TARGET}.py, el perímetro del rectángulo con vértices (1.5, 7.4) y (6.8, 2.3) debería ser 20.8.",
            )
