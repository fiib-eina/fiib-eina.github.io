"""Pruebas para el ejercicio de la habitación de hotel"""

import unittest
import subprocess
import sys

TARGET = "hotel"


def run(habitacion):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{habitacion}\n",
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.strip().splitlines()
    return float(lines[-3]), float(lines[-1])


class RectanguloTest(unittest.TestCase):
    def test_habitacion_0(self):
        (planta, numero) = run(0)
        with self.subTest("Planta de la habitación 0."):
            self.assertEqual(
                planta,
                0,
                msg=f"En {TARGET}.py, la planta de la habitación 0 debería ser 0.",
            )
        with self.subTest("Número de la habitación 0 debería ser 0."):
            self.assertEqual(
                numero,
                0,
                msg=f"En {TARGET}.py, el número de la habitación 0 debería ser 0.",
            )

    def test_habitacion_514(self):
        (planta, numero) = run(514)
        with self.subTest("Planta de la habitación 514."):
            self.assertEqual(
                planta,
                5,
                msg=f"En {TARGET}.py, la planta de la habitación 514 debería ser 5.",
            )
        with self.subTest("Número de la habitación 514."):
            self.assertEqual(
                numero,
                14,
                msg=f"En {TARGET}.py, el número de la habitación 514 debería ser 14.",
            )

    def test_habitacion_1803(self):
        (planta, numero) = run(1803)
        with self.subTest("Planta de la habitación 1803."):
            self.assertEqual(
                planta,
                18,
                msg=f"En {TARGET}.py, la planta de la habitación 1803 debería ser 18.",
            )
        with self.subTest("Número de la habitación 1803."):
            self.assertEqual(
                numero,
                3,
                msg=f"En {TARGET}.py, el número de la habitación 1803 debería ser 3.",
            )
