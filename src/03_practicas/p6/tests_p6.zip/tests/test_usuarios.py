# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
import subprocess
import os

TARGET = "usuarios"

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("1\n1\n1\n1\n+\n")
sys.stdout = StringIO()

import usuarios

sys.stdin = stdin_backup
sys.stdout = stdout_backup


class UsuariosTest(unittest.TestCase):
    def tests_leer_usuarios(self):
        casos = [
            # entrada. esperado is built from entrada
            "",
            "alice:password123\nbob:qwerty\n",
            "charlie:abc123\n",
        ]

        for input in casos:
            esperado = [
                usuarios.Usuario(line.split(":")[0], line.split(":")[1])
                for line in input.splitlines()
                if line.strip() != ""
            ]
            with self.subTest(f"{input} -> {esperado}"):
                with open("usuarios.txt", "w") as f:
                    f.write(input)
                actual = usuarios.leer_usuarios()
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )

    def tests_guardar_usuarios(self):
        casos = [
            # (entrada, esperado)
            [],
            [usuarios.Usuario("charlie", "abc123")],
            [
                usuarios.Usuario("alice", "password123"),
                usuarios.Usuario("bob", "qwert"),
            ],
        ]

        for input in casos:
            esperado = "".join(
                f"{usuario.nombre}:{usuario.contrasena}\n" for usuario in input
            )
            with self.subTest(f"{input} -> {esperado}"):
                usuarios.guardar_usuarios(input)
                with open("usuarios.txt", "r") as f:
                    actual = f.read()
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )

    def tests_buscar_usuario(self):
        usuarios_list = [
            usuarios.Usuario("alice", "password123"),
            usuarios.Usuario("bob", "qwerty"),
            usuarios.Usuario("charlie", "abc123"),
        ]
        usuarios.guardar_usuarios(usuarios_list)

        casos = [
            # (entrada, esperado)
            ("alice", usuarios.Usuario("alice", "password123")),
            ("bob", usuarios.Usuario("bob", "qwerty")),
            ("charlie", usuarios.Usuario("charlie", "abc123")),
            ("dave", None),
        ]

        for input, esperado in casos:
            with self.subTest(f"{input} -> {esperado}"):
                actual = usuarios.buscar_usuario(input, usuarios_list)
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )
