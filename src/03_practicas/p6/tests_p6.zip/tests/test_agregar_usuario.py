# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
import subprocess
import os

TARGET = "agregar_usuario"

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("esteusuariolohacreadoeltest\npuedesborrarlo\n")
sys.stdout = StringIO()

import agregar_usuario

sys.stdin = stdin_backup
sys.stdout = stdout_backup


def run(file_content, usuario, contrasena):
    with open("usuarios.txt", "w") as f:
        f.write(file_content)
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{usuario}\n{contrasena}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)

    salida_actual = proc.stdout.strip()  # Última línea del output
    with open("usuarios.txt", "r") as f:
        fichero_actual = f.read()
    return salida_actual, fichero_actual


class AgregarUsuarioTest(unittest.TestCase):

    def tests_agregar_usuario(self):
        file_content = "alice:password123\nbob:qwerty\n"
        casos = [
            # (entrada, esperado)
            (("charlie", "abc123"), True),  # nuevo usuario
            (("alice", "newpassword"), False),  # usuario existente
        ]

        for (usuario, contrasena), (nuevo) in casos:
            with self.subTest(
                f"{usuario}:{contrasena} -> {'nuevo' if nuevo else 'existente'}"
            ):
                salida_actual, fichero_actual = run(
                    file_content, usuario, contrasena
                )
                if nuevo:
                    self.assertIn(
                        f"Usuario {usuario} añadido correctamente",
                        salida_actual,
                        msg=f"ERROR: Para {usuario}:{contrasena}, el programa debería indicar que el usuario se añadió correctamente, pero se obtuvo {salida_actual}",
                    )
                    self.assertIn(
                        f"{usuario}:{contrasena}\n",
                        fichero_actual,
                        msg=f"ERROR: Para {usuario}:{contrasena}, el usuario debería haberse añadido al fichero, pero el contenido actual es:\n{fichero_actual}",
                    )
                else:
                    self.assertIn(
                        f"El usuario {usuario} ya existe",
                        salida_actual,
                        msg=f"ERROR: Para {usuario}:{contrasena}, el programa debería indicar que el usuario ya existe, pero se obtuvo {salida_actual}",
                    )
                    self.assertNotIn(
                        f"{usuario}:{contrasena}\n",
                        fichero_actual,
                        msg=f"ERROR: Para {usuario}:{contrasena}, el usuario no debería haberse añadido al fichero, pero el contenido actual es:\n{fichero_actual}",
                    )
