# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
import subprocess
import os

TARGET = "cuenta_letras"

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("poker_face.txt\n")
sys.stdout = StringIO()

import cuenta_letras

sys.stdin = stdin_backup
sys.stdout = stdout_backup


def run(content):
    nombre_fichero = "test_input.txt"
    with open(nombre_fichero, "w") as f:
        f.write(f"{content}\n")
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{nombre_fichero}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)

    return [
        int(
            line.split(":")[-1]
        )  # Resistente a primer resultado en misma line aque prompt
        for line in proc.stdout.splitlines()
        if ":" in line
    ]


class CuentaLetrasTest(unittest.TestCase):
    def tests_obtener_indice(self):
        casos = [
            # (entrada, esperado)
            ("a", 0),
            ("A", 0),
            ("z", 25),
            ("Z", 25),
            ("b", 1),
            ("B", 1),
            ("1", -1),
            (" ", -1),
            ("@", -1),
        ]

        for input, esperado in casos:
            with self.subTest(f"{input} -> {esperado}"):
                actual = cuenta_letras.obtener_indice(input)
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )

    def tests_obtener_letra(self):
        casos = [
            # (entrada, esperado)
            (0, "a"),
            (25, "z"),
            (1, "b"),
            (24, "y"),
        ]

        for input, esperado in casos:
            with self.subTest(f"{input} -> {esperado}"):
                actual = cuenta_letras.obtener_letra(input)
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )

    def tests_contar_letras(self):
        casos = [
            # (entrada, esperado)
            ("abc", [1, 1, 1] + [0] * 23),
            ("aAaA", [4] + [0] * 25),
            ("xyzXYZ", [0] * 23 + [2, 2, 2]),
            ("123", [0] * 26),
            ("", [0] * 26),
        ]

        for input, esperado in casos:
            with self.subTest(f"{input} -> {esperado}"):
                actual = cuenta_letras.contar_letras(input)
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )

    def tests_filtrar_velocidades(self):
        casos = [
            # (entrada, esperado)
            (["abc"], [1, 1, 1] + [0] * 23),
            (["aAaA"], [4] + [0] * 25),
            (["xyzXYZ"], [0] * 23 + [2, 2, 2]),
            (["123"], [0] * 26),
            ([""], [0] * 26),
        ]

        for input, esperado in casos:
            with self.subTest(f"{input} -> {esperado}"):
                actual = run(input)
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )
