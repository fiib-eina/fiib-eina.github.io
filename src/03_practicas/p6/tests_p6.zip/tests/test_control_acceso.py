# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
import subprocess
import os

TARGET = "control_acceso"

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("esteusuariolohacreadoeltest\npuedesborrarlo\n")
sys.stdout = StringIO()

import control_acceso

sys.stdin = stdin_backup
sys.stdout = stdout_backup


def run(file_content, usuario, contrasena):
    with open("usuarios.txt", "w") as f:
        f.write(file_content)
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{usuario}\n{contrasena}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)

    salida_actual = proc.stdout.strip()  # Última línea del output
    with open("usuarios.txt", "r") as f:
        fichero_actual = f.read()
    return salida_actual, fichero_actual


class ControlAccesoTest(unittest.TestCase):
    def tests_control_acceso(self):
        file_content = "alice:password123\nbob:qwerty\n"
        casos = [
            # (entrada, esperado)
            # ((user, pass), (existe, correcto))
            (("alice", "password123"), (True, True)),
            (("alice", "wrongpassword"), (True, False)),
            (("charlie", "abc123"), (False, False)),
        ]

        for (usuario, contrasena), (existe, correcto) in casos:
            with self.subTest(
                f"{usuario}:{contrasena} -> {'existe' if existe else 'no existe'}, {'correcto' if correcto else 'incorrecto'}"
            ):
                salida_actual, fichero_actual = run(
                    file_content, usuario, contrasena
                )
                self.assertEqual(
                    fichero_actual,
                    file_content,
                    msg=f"ERROR: El contenido del fichero no debería cambiar, pero se obtuvo {fichero_actual}",
                )
                if existe:
                    if correcto:
                        self.assertIn(
                            f"Bienvenida/o {usuario}",
                            salida_actual,
                            msg=f"ERROR: Para {usuario}:{contrasena}, el programa debería dar la bienvenida, pero se obtuvo {salida_actual}",
                        )
                    else:
                        self.assertIn(
                            f"Contraseña incorrecta",
                            salida_actual,
                            msg=f"ERROR: Para {usuario}:{contrasena}, el programa debería indicar que la contraseña es incorrecta, pero se obtuvo {salida_actual}",
                        )
                else:
                    self.assertIn(
                        f"Usuario no existe",
                        salida_actual,
                        msg=f"ERROR: Para {usuario}:{contrasena}, el programa debería indicar que el usuario no existe, pero se obtuvo {salida_actual}",
                    )
