# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
import subprocess
import os

TARGET = "filtrar_velocidades"

stdin_backup = sys.stdin
stdout_backup = sys.stdout
sys.stdin = StringIO("1\n1\n1\n1\n+\n")
sys.stdout = StringIO()

with open("velocidades.txt", "w") as f:
    f.write("1.0\n1.0\n2.0\n1.0\n5.0\n")
import filtrar_velocidades

sys.stdin = stdin_backup
sys.stdout = stdout_backup


def run(content):
    with open("velocidades_filtradas.txt", "w") as f:
        f.write("No output\n")
    with open("velocidades.txt", "w") as f:
        f.write("".join(f"{x}\n" for x in content))
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    salida_actual = proc.stdout.strip()
    with open("velocidades_filtradas.txt", "r") as f:
        fichero_actual = [round(float(x), 4) for x in f]
    return (salida_actual, fichero_actual)


class CuentaLetrasTest(unittest.TestCase):
    def tests_media_movil(self):
        casos = [
            # (entrada, esperado)
            ([1.0, 2.0, 3.0], [2.0]),
            ([1.0, 2.0, 3.0, 4.0], [2.0, 3.0]),
            ([1.0, 2.0, 3.0, 4.0, 5.0], [2.0, 3.0, 4.0]),
            ([1.0], []),
            ([1.0, 2.0], []),
        ]

        for input, esperado in casos:
            with self.subTest(f"{input} -> {esperado}"):
                actual = filtrar_velocidades.media_movil(input)
                self.assertEqual(
                    actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {actual}.",
                )

    def tests_filtrar_velocidades(self):
        casos = [
            # (entrada, esperado)
            ([1.0, 1.0, 1.0], [1.0]),
            ([1.0, 2.0, 3.0], [2.0]),
            ([1.0, 2.0, 3.0, 4.0], [2.0, 3.0]),
            ([1.0, 2.0], []),
            ([], []),
            ([1.0, 1.0, 2.0, 1.0, 5.0], [1.3333, 1.3333, 2.6667]),
        ]

        for input, esperado in casos:
            with self.subTest(f"{input} -> {esperado}"):
                salida_actual, fichero_actual = run(input)
                self.assertEqual(
                    salida_actual,
                    "OK",
                    msg="El programa debe imprimir OK al finalizar.",
                )
                self.assertEqual(
                    fichero_actual,
                    esperado,
                    msg=f"ERROR: Para la entrada {input}, se esperaba {esperado} pero se obtuvo {fichero_actual}.",
                )
