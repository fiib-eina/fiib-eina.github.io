"""Pruebas para el problema de la serie de Leibniz."""

import math
import unittest
import subprocess
import sys
import os

TARGET = "leibniz"


def run(terms: int) -> list[float]:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{terms}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lines = proc.stdout.splitlines()
    return [float(line.rsplit(":", 1)[1].strip()) for line in lines[-3:]]


class LeibnizTest(unittest.TestCase):
    def tests_leibniz(self):
        casos = [
            # (términos, aprox_esperado, pi_real_esperado, error_esperado)
            (0, 0.0, math.pi, math.pi),
            (10, 3.0418396189294032, math.pi, 0.09975303466038987),
            (100, 3.13159290, math.pi, 0.00999975),
        ]

        for (
            terminos,
            aprox_esperado,
            pi_real_esperado,
            error_esperado,
        ) in casos:
            aprox, pi_real, error = run(terminos)

            with self.subTest(f"Aproximación a π con {terminos} términos"):
                self.assertAlmostEqual(
                    aprox,
                    aprox_esperado,
                    places=8,
                    msg=f"\nEn {TARGET}.py, con {terminos} términos, la aproximación a π debe ser aproximadamente {aprox_esperado}, pero se obtuvo {aprox}.",
                )
            with self.subTest(f"Valor real de π con {terminos} términos"):
                self.assertAlmostEqual(
                    pi_real,
                    pi_real_esperado,
                    places=8,
                    msg=f"\nEn {TARGET}.py, con {terminos} términos, el valor real de π no debe cambiar.",
                )
            with self.subTest(f"Error con {terminos} términos"):
                self.assertAlmostEqual(
                    error,
                    error_esperado,
                    places=8,
                    msg=f"\nEn {TARGET}.py, con {terminos} términos, el error debe ser aproximadamente {error_esperado}, pero se obtuvo {error}.",
                )
