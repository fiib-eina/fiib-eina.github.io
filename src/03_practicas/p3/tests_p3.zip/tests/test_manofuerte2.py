"""Pruebas para el problema del juego mano fuerte, mano débil."""

import unittest
import subprocess
import sys
import os

TARGET = "manofuerte2"


def run(carta1: int, carta2: int) -> tuple[list[int], list[str]]:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{carta1}\n{carta2}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    lineas = proc.stdout.splitlines()
    tabla = [
        "".join(caracter for caracter in line if caracter in {"o", "x", "."})
        for line in lineas
        if "|" in line
    ]
    return [int(line.rsplit(":", 1)[1].strip()) for line in lineas[-3:]], tabla


TABLA_ESPERADA_14_14 = [
    "",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    "oooooooooooo.",
    ".............",
]

TABLA_ESPERADA_8_10 = [
    "",
    "oooooooo.....",
    "oooooooo.....",
    "oooooooo.....",
    "oooooooo.....",
    "oooooooo.....",
    "oooooooo.....",
    "oooooo.......",
    "oooooo...xxxx",
    ".........xxxx",
    ".......xxxxxx",
    ".......xxxxxx",
    ".......xxxxxx",
    ".......xxxxxx",
]


class ManoFuerteTest(unittest.TestCase):
    def tests_mano_fuerte(self):
        casos = [
            # ([carta_1, carta_2], victorias_esperadas, empates_esperados, derrotas_esperadas, tabla_esperada)
            ([14, 14], 144, 25, 0, TABLA_ESPERADA_14_14),
            ([8, 10], 60, 77, 32, TABLA_ESPERADA_8_10),
        ]

        for (
            [carta_1, carta_2],
            victorias_esperadas,
            empates_esperados,
            derrotas_esperadas,
            tabla_esperada,
        ) in casos:
            [victorias, empates, derrotas], tabla = run(carta_1, carta_2)

            with self.subTest(f"Victorias con cartas {carta_1} y {carta_2}"):
                self.assertEqual(
                    victorias,
                    victorias_esperadas,
                    msg=f"\nEn {TARGET}.py, con cartas {carta_1} y {carta_2}, el número de victorias debe ser {victorias_esperadas}, pero se obtuvo {victorias}.",
                )
            with self.subTest(f"Empates con cartas {carta_1} y {carta_2}"):
                self.assertEqual(
                    empates,
                    empates_esperados,
                    msg=f"\nEn {TARGET}.py, con cartas {carta_1} y {carta_2}, el número de empates debe ser {empates_esperados}, pero se obtuvo {empates}.",
                )
            with self.subTest(f"Derrotas con cartas {carta_1} y {carta_2}"):
                self.assertEqual(
                    derrotas,
                    derrotas_esperadas,
                    msg=f"\nEn {TARGET}.py, con cartas {carta_1} y {carta_2}, el número de derrotas debe ser {derrotas_esperadas}, pero se obtuvo {derrotas}.",
                )
            with self.subTest(f"Tabla con cartas {carta_1} y {carta_2}"):
                self.assertEqual(
                    tabla,
                    tabla_esperada,
                    msg=f"\nEn {TARGET}.py, con cartas {carta_1} y {carta_2}, la tabla debe ser {tabla_esperada}, pero se obtuvo {tabla}.",
                )
