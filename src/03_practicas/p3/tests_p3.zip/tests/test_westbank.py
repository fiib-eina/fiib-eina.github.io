"""Pruebas para el problema de la caja fuerte del West Bank."""

import unittest
import subprocess
import sys
import os

TARGET = "westbank"


def run(numeros: list[int]) -> list[str]:
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input="\n".join(map(str, numeros)) + "\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)
    return [
        line.strip()
        for line in proc.stdout.splitlines()
        if line.strip().lower() in {"tick", "clonk"}
    ]


class WestBankTest(unittest.TestCase):
    def tests_westbank(self):
        casos = [
            # (números, sonidos_esperados)
            ([8, 23, 42, 0], ["tick", "tick", "tick"]),
            ([8, 1, 8, 23, 42, 0], ["tick", "clonk", "tick", "tick", "tick"]),
            ([1, 2, 0], ["clonk", "clonk"]),
        ]

        for numeros, sonidos_esperados in casos:
            secuencia_obtenida = run(numeros)

            with self.subTest(f"Secuencia con números {numeros}"):
                self.assertEqual(
                    secuencia_obtenida,
                    sonidos_esperados,
                    msg=f"\nEn {TARGET}.py, con números {numeros}, la secuencia debe ser {sonidos_esperados}, pero se obtuvo {secuencia_obtenida}.",
                )
