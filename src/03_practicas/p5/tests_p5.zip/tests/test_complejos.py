import unittest
import complejos

TARGET = "complejos"


class ComplejosTest(unittest.TestCase):
    def test_constructor(self):
        casos = [
            # (r, i, real, imag)
            (0.0, 0.0, 0.0, 0.0),
            (1.0, 2.0, 1.0, 2.0),
            (-3.0, 4.0, -3.0, 4.0),
            (5.5, -6.6, 5.5, -6.6),
        ]
        for r, i, real, imag in casos:
            with self.subTest(f"Constructor Complejo({r}, {i})"):
                c = complejos.Complejo(r, i)
                if type(c) is not complejos.Complejo:
                    self.fail(
                        f"En {TARGET}.py: El constructor Complejo({r}, {i}) debe retornar una instancia de Complejo, pero se obtuvo {type(c).__name__}."
                    )
                if c.real != real or c.imag != imag:
                    self.fail(
                        f"En {TARGET}.py: El complejo creado con Complejo({r}, {i}) debe tener real={real} e imag={imag}, pero se obtuvo real={c.real} e imag={c.imag}."
                    )

    def test_str_complejo(self):
        casos = [
            # (r, i, expected)
            (0.0, 0.0, "0.0+0.0i"),
            (4.0, 6.0, "4.0+6.0i"),
            (-4.0, 6.0, "-4.0+6.0i"),
            (4.0, -6.0, "4.0-6.0i"),
            (-4.0, -6.0, "-4.0-6.0i"),
            (3.22, 4.111111111111, "3.22+4.1111i"),
            (3.22, -4.111111111111, "3.22-4.1111i"),
        ]
        for r, i, expected in casos:
            with self.subTest(f"str_complejo({r}, {i})"):
                c = complejos.Complejo(r, i)
                res = complejos.str_complejo(c)
                self.assertEqual(
                    res,
                    expected,
                    msg=f"En {TARGET}.py: La representación de {c} debe ser '{expected}', pero se obtuvo '{res}'.",
                )

    def test_sumar(self):
        casos = [
            # (r1, i1, r2, i2, r3, i3)
            (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            (1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
            (0.0, 1.0, 0.0, 0.0, 0.0, 1.0),
            (1.0, 1.0, 1.0, 1.0, 2.0, 2.0),
            (1.0, 1.0, -1.0, -1.0, 0.0, 0.0),
            (1.0, 1.0, 1.0, -1.0, 2.0, 0.0),
        ]
        for r1, i1, r2, i2, r3, i3 in casos:
            with self.subTest(f"sumar({r1}+{i1}i, {r2}+{i2}i)"):
                c1 = complejos.Complejo(r1, i1)
                c2 = complejos.Complejo(r2, i2)
                c3 = complejos.Complejo(r3, i3)
                res = complejos.sumar(c1, c2)
                self.assertEqual(
                    res.real,
                    c3.real,
                    msg=f"En {TARGET}.py: La suma de {c1} y {c2} debe ser {c3}, pero se obtuvo {res}.",
                )
                self.assertEqual(
                    res.imag,
                    c3.imag,
                    msg=f"En {TARGET}.py: La suma de {c1} y {c2} debe ser {c3}, pero se obtuvo {res}.",
                )

    def test_restar(self):
        casos = [
            # (r1, i1, r2, i2, r3, i3)
            (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            (1.0, 0.0, 0.0, 0.0, 1.0, 0.0),
            (0.0, 1.0, 0.0, 0.0, 0.0, 1.0),
            (1.0, 1.0, 1.0, 1.0, 0.0, 0.0),
            (1.0, 1.0, -1.0, -1.0, 2.0, 2.0),
            (1.0, 1.0, 1.0, -1.0, 0.0, 2.0),
        ]
        for r1, i1, r2, i2, r3, i3 in casos:
            with self.subTest(f"restar({r1}+{i1}i, {r2}+{i2}i)"):
                c1 = complejos.Complejo(r1, i1)
                c2 = complejos.Complejo(r2, i2)
                c3 = complejos.Complejo(r3, i3)
                res = complejos.restar(c1, c2)
                self.assertEqual(
                    res.real,
                    c3.real,
                    msg=f"En {TARGET}.py: La resta de {c1} y {c2} debe ser {c3}, pero se obtuvo {res}.",
                )
                self.assertEqual(
                    res.imag,
                    c3.imag,
                    msg=f"En {TARGET}.py: La resta de {c1} y {c2} debe ser {c3}, pero se obtuvo {res}.",
                )

    def test_modulo(self):
        casos = [
            # (r, i, expected)
            (0.0, 0.0, 0.0),
            (1.0, 0.0, 1.0),
            (0.0, 1.0, 1.0),
            (1.0, 1.0, 1.41421),
            (1.0, -1.0, 1.41421),
            (-1.0, 1.0, 1.41422),
            (-1.0, -1.0, 1.41421),
            (1.0, 2.0, 2.23607),
            (1.0, -2.0, 2.23607),
            (-1.0, 2.0, 2.23607),
            (-1.0, -2.0, 2.23607),
        ]
        for r, i, expected in casos:
            with self.subTest(f"modulo({r}+{i}i)"):
                c = complejos.Complejo(r, i)
                res = complejos.modulo(c)
                self.assertAlmostEqual(
                    res,
                    expected,
                    places=4,
                    msg=f"En {TARGET}.py: El módulo de {c} debe ser aproximadamente {expected}, pero se obtuvo {res}.",
                )

    def test_compare(self):
        casos = [
            # (r1, i1, r2, i2, expected)
            (0.0, 0.0, 0.0, 0.0, "igual"),
            (1.0, 0.0, 0.0, 0.0, "mayor"),
            (0.0, 1.0, 0.0, 0.0, "mayor"),
            (0.0, 0.0, 1.0, 0.0, "menor"),
            (0.0, 0.0, 0.0, 1.0, "menor"),
            (1.0, 1.0, 1.0, 1.0, "igual"),
            (1.0, 1.0, 1.0, -1.0, "igual"),
            (1.0, 1.0, -1.0, 1.0, "igual"),
            (1.0, 1.0, -1.0, -1.0, "igual"),
            (1.0, 1.0, 2.0, 2.0, "menor"),
            (2.0, 2.0, 1.0, 1.0, "mayor"),
        ]
        for r1, i1, r2, i2, expected in casos:
            with self.subTest(f"Comparar {r1}+{i1}i y {r2}+{i2}i"):
                c1 = complejos.Complejo(r1, i1)
                c2 = complejos.Complejo(r2, i2)
                res_menor = complejos.menor_que(c1, c2)
                res_mayor = complejos.mayor_que(c1, c2)
                res_igual = complejos.igual_que(c1, c2)
                self.assertEqual(
                    res_menor,
                    (expected == "menor"),
                    msg=f"En {TARGET}.py: menor_que({c1}, {c2}) debe ser {expected == 'menor'}, pero se obtuvo {res_menor}.",
                )
                self.assertEqual(
                    res_mayor,
                    (expected == "mayor"),
                    msg=f"En {TARGET}.py: mayor_que({c1}, {c2}) debe ser {expected == 'mayor'}, pero se obtuvo {res_mayor}.",
                )
                self.assertEqual(
                    res_igual,
                    (expected == "igual"),
                    msg=f"En {TARGET}.py: igual_que({c1}, {c2}) debe ser {expected == 'igual'}, pero se obtuvo {res_igual}.",
                )
