# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
import subprocess
import os
from types import SimpleNamespace

TARGET = "calculadora"


try:
    stdin_backup = sys.stdin
    stdout_backup = sys.stdout
    sys.stdin = StringIO("1\n1\n1\n1\n+\n")
    sys.stdout = StringIO()

    import calculadora

    sys.stdin = stdin_backup
    sys.stdout = stdout_backup
except Exception as e:
    print(f"\n***** ERROR al importar {TARGET}.py: {e}")

    def _err(*args, **kwargs):
        raise ImportError(f"ERROR: El modulo no pudo ser importado: {e}")

    amigos = SimpleNamespace(
        Complejo=_err,
        str_complejo=_err,
        sumar=_err,
        restar=_err,
        modulo=_err,
        mayor_que=_err,
        menor_que=_err,
        igual_que=_err,
    )


def run(ar, ai, br, bi, op):
    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input=f"{ar}\n{ai}\n{br}\n{bi}\n{op}\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)

    return proc.stdout.strip()


class CalculadoraTest(unittest.TestCase):
    """Clase de pruebas para el problema de la calculadora de números complejos."""

    def assertEndsWith(self, actual: str, esperado: str, msg_operacion: str):
        """Asserción personalizada para verificar que una cadena termina con otra."""
        self.assertEqual(
            actual[-len(esperado) :],
            esperado,
            msg=f"\nEn {TARGET}.py: La operación {msg_operacion} debe resultar en '{esperado}', pero se obtuvo '{actual[-len(esperado) :]}'.",
        )

    def tests_calculadora(self):
        casos = [
            # (entrada, esperado)
            ((1.0, 1.0, 1.0, 1.0, "+"), "2.0+2.0i"),
            ((1.0, 1.0, 1.0, 1.0, "-"), "0.0+0.0i"),
            ((1.0, 1.0, 1.0, 1.0, "*"), "Operación no válida"),
            ((1.0, 1.0, 1.0, 1.0, "/"), "Operación no válida"),
            ((2.0, 3.0, 4.0, 5.0, "+"), "6.0+8.0i"),
            ((2.0, 3.0, 4.0, 5.0, "-"), "-2.0-2.0i"),
        ]

        for (ar, ai, br, bi, op), esperado in casos:
            actual = run(ar, ai, br, bi, op)
            with self.subTest(f"{ar}+{ai}i {op} {br}+{bi}i"):
                self.assertEndsWith(
                    actual,
                    esperado,
                    msg_operacion=f"{ar}+{ai}i {op} {br}+{bi}i",
                )
