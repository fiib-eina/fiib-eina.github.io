# type: ignore[reportUnknownArgumentType]
# pylint: disable=wrong-import-position

"""Pruebas para el problema de los números amigos."""

from io import StringIO
import unittest
import sys
import signal
import subprocess
import os
from types import SimpleNamespace

TARGET = "lista_complejos"


def handler(signum, frame):
    raise TimeoutError(
        f"La ejecución del import de {TARGET}.py excedió el tiempo límite."
    )


try:
    stdin_backup = sys.stdin
    stdout_backup = sys.stdout
    sys.stdin = StringIO("1\n1\n2\n")
    sys.stdout = StringIO()

    signal.signal(signal.SIGALRM, handler)
    signal.alarm(1)
    from complejos import Complejo
    import lista_complejos

    signal.alarm(0)
    sys.stdin = stdin_backup
    sys.stdout = stdout_backup
except Exception as e:
    print(f"\n***** ERROR al importar {TARGET}.py: {e}")

    def _err(*args, **kwargs):
        raise ImportError(f"ERROR: El modulo no pudo ser importado: {e}")

    amigos = SimpleNamespace(
        generar_complejo_aleatorio=_err,
        generar_lista_complejos=_err,
        str_lista_complejos=_err,
        minimo_lista_complejos=_err,
        suma_lista_complejos=_err,
        filtrar_primer_cuadrante=_err,
    )


class ComplejoSimple:
    real: float
    imag: float

    def __init__(self, r, i):
        assert isinstance(r, float) and isinstance(i, (int, float)), (
            f"Los argumentos del constructor Complejo deben ser FLOAT: real={r} imag={i}"
        )
        self.real = r
        self.imag = i

    @staticmethod
    def parse(cadena):
        try:
            cadena = cadena.strip()
            r_str, i_str = cadena.split("+")
            r = float(r_str)
            i = float(i_str[:-1])
            return ComplejoSimple(r, i)
        except Exception as e:
            raise ValueError(f"Error al parsear el complejo '{cadena}': {e}")

    def __str(self):
        return (
            f"{self.real}+{self.imag}i"
            if self.imag >= 0
            else f"{self.real}{self.imag}i"
        )

    def __repr__(self):
        return self.__str()

    def __ge__(self, other):
        return (self.real**2 + self.imag**2) >= (other.real**2 + other.imag**2)

    def __gt__(self, other):
        return (self.real**2 + self.imag**2) > (other.real**2 + other.imag**2)

    def __le__(self, other):
        return (self.real**2 + self.imag**2) <= (other.real**2 + other.imag**2)

    def __lt__(self, other):
        return (self.real**2 + self.imag**2) < (other.real**2 + other.imag**2)

    def __eq__(self, other):
        return (
            abs(self.real - other.real) < 0.01
            and abs(self.imag - other.imag) < 0.01
        )

    def __add__(self, other):
        return ComplejoSimple(self.real + other.real, self.imag + other.imag)


def run(
    nums,
) -> tuple[
    list[ComplejoSimple], ComplejoSimple, ComplejoSimple, list[ComplejoSimple]
]:
    assert all(isinstance(x, (int, float)) for x in nums), (
        "Todos los elementos de nums deben ser números (int o float)."
    )

    proc = subprocess.run(
        [sys.executable, f"{TARGET}.py"],
        input="\n".join(str(x) for x in nums) + "\n",
        capture_output=True,
        check=False,
        encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(proc.stdout)

    out = [l for l in proc.stdout.splitlines() if l.strip()]

    lista = [ComplejoSimple.parse(c) for c in out[-7].strip().split(", ")]
    menor = ComplejoSimple.parse(out[-5].strip())
    suma = ComplejoSimple.parse(out[-3].strip())
    quad_uno = [ComplejoSimple.parse(c) for c in out[-1].strip().split(", ")]
    return (lista, menor, suma, quad_uno)


class ListaComplejosTest(unittest.TestCase):
    """Clase de pruebas para el problema de lista de números complejos."""

    def test_generar_complejo_aleatorio(self):
        casos = [
            # (x, y)
            (0.0, 1.0),
            (-5, 5.0),
            (10.0, 20.0),
        ]
        for x, y in casos:
            for _ in range(3):
                c = lista_complejos.generar_complejo_aleatorio(x, y)
                with self.subTest(
                    f"Generar complejo aleatorio entre {x} y {y}"
                ):
                    if not (x <= c.real <= y and x <= c.imag <= y):
                        self.fail(
                            f"En {TARGET}.py: El complejo generado {c} no está en el rango [{x}, {y}]."
                        )

    def test_str_lista_complejos(self):
        casos = [
            # (entrada, esperado)
            ([ComplejoSimple(1.0, 2.0)], "1.0+2.0i"),
            ([ComplejoSimple(1.0, -2.0)], "1.0-2.0i"),
            ([ComplejoSimple(0.0, 0.0)], "0.0+0.0i"),
            ([ComplejoSimple(-1.0, -1.0)], "-1.0-1.0i"),
        ]

        for lista, esperado in casos:
            res = lista_complejos.str_lista_complejos(lista)
            with self.subTest(f"str_lista_complejos({lista})"):
                if res != esperado:
                    self.fail(
                        f"En {TARGET}.py: La representación de la lista de complejos {lista} debe ser '{esperado}', pero se obtuvo '{res}'."
                    )

    def test_minimo_lista_complejos(self):
        casos = [
            # (entrada, esperado)
            ([ComplejoSimple(1.0, 2.0)], ComplejoSimple(1.0, 2.0)),
            (
                [ComplejoSimple(1.0, 2.0), ComplejoSimple(3.0, 4.0)],
                ComplejoSimple(1.0, 2.0),
            ),
            (
                [ComplejoSimple(3.0, 4.0), ComplejoSimple(1.0, 2.0)],
                ComplejoSimple(1.0, 2.0),
            ),
            (
                [ComplejoSimple(-1.0, -1.0), ComplejoSimple(1.0, 1.0)],
                ComplejoSimple(-1.0, -1.0),
            ),
        ]

        for lista, esperado in casos:
            res = lista_complejos.minimo_lista_complejos(lista)
            with self.subTest(f"minimo_lista_complejos({lista})"):
                if res != esperado:
                    self.fail(
                        f"En {TARGET}.py: El número complejo de menor módulo en la lista {lista} debe ser '{esperado}', pero se obtuvo '{res}'."
                    )

    def test_suma_lista_complejos(self):
        casos = [
            # (entrada, esperado)
            ([ComplejoSimple(1.0, 2.0)], ComplejoSimple(1.0, 2.0)),
            (
                [ComplejoSimple(1.0, 2.0), ComplejoSimple(3.0, 4.0)],
                ComplejoSimple(4.0, 6.0),
            ),
            (
                [ComplejoSimple(-1.0, -1.0), ComplejoSimple(1.0, 1.0)],
                ComplejoSimple(0.0, 0.0),
            ),
        ]

        for lista, esperado in casos:
            res = lista_complejos.suma_lista_complejos(lista)
            with self.subTest(f"suma_lista_complejos({lista})"):
                if res != esperado:
                    self.fail(
                        f"En {TARGET}.py: La suma de los números complejos en la lista {lista} debe ser '{esperado}', pero se obtuvo '{res}'."
                    )

    def test_filtrar_primer_cuadrante(self):
        casos = [
            # (entrada, esperado)
            ([ComplejoSimple(1.0, 2.0)], [ComplejoSimple(1.0, 2.0)]),
            ([ComplejoSimple(-1.0, 2.0)], []),
            ([ComplejoSimple(1.0, -2.0)], []),
            ([ComplejoSimple(-1.0, -2.0)], []),
            (
                [
                    ComplejoSimple(1.0, 2.0),
                    ComplejoSimple(-1.0, 2.0),
                    ComplejoSimple(1.0, -2.0),
                ],
                [ComplejoSimple(1.0, 2.0)],
            ),
        ]

        for lista, esperado in casos:
            res = lista_complejos.filtrar_primer_cuadrante(lista)
            with self.subTest(f"filtrar_primer_cuadrante({lista})"):
                if res != esperado:
                    self.fail(
                        f"En {TARGET}.py: La lista de números complejos en el primer cuadrante de {lista} debe ser '{esperado}', pero se obtuvo '{res}'."
                    )

    def tests_lista_complejos(self):
        casos = [
            # (entrada, (len, min, max))
            (
                [1, 1.0, 2.0],
                (1, ComplejoSimple(1.0, 1.0), ComplejoSimple(2.0, 2.0)),
            ),
            (
                [4, 2.0, 1.0, 3.0, 4.0],
                (4, ComplejoSimple(3.0, 3.0), ComplejoSimple(4.0, 4.0)),
            ),
        ]

        for nums, (len_esperado, min_esperado, max_esperado) in casos:
            (lista_actual, menor_actual, suma_actual, quad_uno_actual) = run(
                nums
            )
            with self.subTest(f"Lista para los valores {nums}"):
                if len(lista_actual) != len_esperado:
                    self.fail(
                        f"En {TARGET}.py: La lista de complejos generada para los valores {nums} debe tener longitud {len_esperado}, pero se obtuvo una lista de longitud {len(lista_actual)}: '{lista_actual}'."
                    )
                if any(
                    not min_esperado <= c <= max_esperado for c in lista_actual
                ):
                    self.fail(
                        f"En {TARGET}.py: Todos los números complejos en la lista generada de {lista_actual} deben estar entre '{min}' y '{max}', pero se obtuvo la lista '{lista_actual}'."
                    )
            with self.subTest(f"Menor para los valores {nums}"):
                min_esperado = min(lista_actual)
                if min_esperado != menor_actual:
                    self.fail(
                        f"En {TARGET}.py: El número complejo con el menor módulo de {lista_actual} debe ser '{min_esperado}', pero se obtuvo '{menor_actual}'."
                    )
            with self.subTest(f"Suma para los valores {nums}"):
                suma_esperado = sum(lista_actual, ComplejoSimple(0.0, 0.0))
                if suma_esperado != suma_actual:
                    self.fail(
                        f"En {TARGET}.py: La suma de los números complejos de {lista_actual} debe ser '{suma_esperado}', pero se obtuvo '{suma_actual}'."
                    )

            with self.subTest(f"Cuadrante 1 para los valores {nums}"):
                if any(c.real <= 0 or c.imag <= 0 for c in quad_uno_actual):
                    self.fail(
                        f"En {TARGET}.py: Todos los números complejos en el primer cuadrante de {lista_actual} deben tener parte real e imaginaria positivas, pero se obtuvo la lista '{quad_uno_actual}'."
                    )
